package TrafficLight;

import static TrafficLight.AppSim.*;
import java.awt.*;
import java.awt.Graphics2D;
import java.awt.geom.*;

/**
 *
 * @author Africana
 */
public class SmartCar extends AppSim {

    class Vec {

        int x, y;

        Vec() {}

        Vec(int xVal, int yVal) //*Constructor
        {
            x = xVal;
            y = yVal;
        }//end Constructor

    }//end Vec Class

   
    //* Car Attributes
    Vec loc = new Vec();
    Image carImage;
    int accl; //Current speed
    static int carWidth = 27; //x-axis dim of car
    static int carLength = 57; //y-axis dim of car
    int iD; //plate number to identify each car
    boolean stall;
    int carW, carL;

    SmartCar( int iDLabel ,int xPos, int yPos,boolean condition) //*Constructor:Each car object is created knowing its start position,lane, speed, iD
    //*Dimentions of the car are also set
    {
        loc.x = xPos;
        loc.y = yPos;
        iD = iDLabel;
        carW = carWidth;
        carL = carLength;
        stall = condition;
    }

    SmartCar(boolean condition,int iDLabel ,int xPos, int yPos) 
    {
        loc.x = xPos;
        loc.y = yPos;
        iD = iDLabel;
        carW = carLength;
        carL = carWidth;
        stall = condition;
    }


    public void drawCar(Graphics2D brush) {
        //draw all the cars below (Resize images in photoShop)
   
        brush.setColor(Color.gray);
        //brush.fill(new Ellipse2D.Float(loc.x, loc.y, carW, carL));
        brush.drawImage(carImage,loc.x, loc.y/*, carW, carL*/,this);
    }
    
    public void printOut()
    {
        System.out.println("Draw Car At"+"\nxLoc: "+loc.x + "\nyLoc: "+loc.y );
    }

}//end SmartCar class
