package TrafficLight;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

public class AppSim extends JApplet {

    //import the various cars
    Image[] northCars, southCars, eastCars, westCars; //* Car image array
    String[] northCarNames, southCarNames, eastCarNames, westCarNames;

    //*Buffer Graphics
    BufferedImage backBuff;
    Graphics2D brush = null;
    
    //New Graphics Objects
    Intersection intersection;
    static TrafficLight[] sideLights;
    static TrafficLight[] roadLights;
    SmartCar[] nCars, sCars, eCars, wCars;
    MediaTracker media;

    //*Number of cars in a givin direction
    int nNCars, nSCars, nECars, nWCars; //where is number of; S=south, etc ...
    volatile int NBCars, WBCars, SBCars, EBCars;

    //Startin Positions of cars
    int NSP, SSP, ESP, WSP;

    //*Lane Positions
    int NL, SL, EL, WL;
    int NR, SR, ER, WR;
    int north, south, east, west;

    //* Frame Resolution
    public static final int FrameX = 600;
    public static final int FrameY = FrameX;
    Container pro = getContentPane();

    @Override
    public void init() {

        setSize(FrameX, FrameY);
        NBCars = SBCars = WBCars = EBCars = 1;
        intersection = new Intersection();
        media = new MediaTracker(this);
        //*Start Threads
        new Thread(new Runnable() {
            public void run() {
                carImage();
            }
        }).start();
        try {
            media.waitForAll();
        } catch (InterruptedException e) {
        }
        backBuff = new BufferedImage(FrameX, FrameY, BufferedImage.TYPE_INT_RGB);
        new Thread(new Runnable() {
            public void run() {
                Graphics g = getGraphics();
                try {
                    while(true){
                    intersection.setNSMove();
                    Thread.sleep(2500);
                    intersection.setEWMove();
                    Thread.sleep(5700);
                    //light.setEastMove(false);//stop east cars
                    }    
                //g.dispose();
                } catch (InterruptedException e) {
                }
            }
        }).start();
        carThread.start();
        System.out.println("Init");
        System.out.println("Intersection: "+Intersection.intersectionNW);
        System.out.println("Intersection: "+(Intersection.roadEWCen-(Intersection.laneSize*2)));
    }//end init()

    @Override
    public synchronized void paint(Graphics paintBrush) throws NullPointerException {
        if (brush == null || pro.getSize().width != 0 || pro.getSize().height != 0) {
            brush = (Graphics2D) backBuff.getGraphics();
        }

        brush = rendering(brush);
        brush.setColor(new Color(35, 41, 42));
        brush.fillRect(0, 0, FrameX, FrameY);
        intersection.drawIntersection(brush);
        drive();
        paintBrush.drawImage(backBuff, 0, 0, pro);
    }//end paint()

    Thread carThread = new Thread(new Runnable() //*Generate and launch cars
    {
        public void run() {
            generate();
            try {

                boolean isRunning = true;
                nCars[0] = new SmartCar(0, NL, NSP, false);
                nCars[0].carImage = northCars[randCol()];

                sCars[0] = new SmartCar(0, SL, SSP, false);
                sCars[0].carImage = southCars[randCol()];

                eCars[0] = new SmartCar(false, 0, ESP, ER);
                eCars[0].carImage = eastCars[randCol()];

                wCars[0] = new SmartCar(false, 0, WSP, WR);
                wCars[0].carImage = westCars[randCol()];
                
                int runup = 0;
                while (isRunning) //*While true:Game Loop extension
                {
                    //*Give the road time to refresh
                    if (NBCars < nNCars)//if thers's one more car to launch
                     {
                     launchNorth();
                     }
                     if (SBCars < nSCars) {
                     launchSouth();
                     }
                     if (EBCars < nECars) {
                     launchEast();
                     }
                     if (WBCars < nWCars) {
                     launchWest();
                     }
                    Thread.sleep(100);
                    repaint();
                    runup++;
                    /* if((WBCars >= nWCars)&&(EBCars >= nECars)&&(SBCars >= nSCars)&&(NBCars >= nNCars))
                     {isRunning = false;}*/
                    if(runup > 170){isRunning = false;}
                }
            } catch (InterruptedException ex) {
            }
        }
    });//end Thread carThread

    synchronized void drive() throws NullPointerException {
       int slowDown = 11;
       int bump = 9;
       int speed = 1;
       int vel = 6;
       
        //*NorthCars
        for (int n = 0; n < NBCars; n++) {
            boolean noCollision = true;
            boolean clearLane = true;
            for(int c = 0; c<n ;c++)
            {
                if(clearLane && (nCars[c].loc.x == nCars[n].loc.x))
                {clearLane = false;}
                else if(clearLane && (nCars[c].loc.x != nCars[n].loc.x))
                {clearLane = true;}
            
                if ((nCars[c].loc.x == nCars[n].loc.x) && (nCars[c].loc.y-bump > nCars[n].loc.y+SmartCar.carLength))
                {noCollision = true;}
                else if ((nCars[c].loc.x == nCars[n].loc.x) && (nCars[c].loc.y-bump <= nCars[n].loc.y+SmartCar.carLength))
                {noCollision = false;}
            }
            
            if ((n==0)||(n>0 && (noCollision || clearLane)))
            {
                if (intersection.getNorthMove()||(nCars[n].loc.y < (Intersection.intersectionNW-SmartCar.carLength)-slowDown)||(nCars[n].loc.y > (Intersection.intersectionNW-SmartCar.carLength))) {
                    nCars[n].loc.y += vel;
                }else if (!intersection.getNorthMove() && (nCars[n].loc.y >= (Intersection.intersectionNW-SmartCar.carLength)-slowDown && nCars[n].loc.y < (Intersection.intersectionNW-SmartCar.carLength))) {
                nCars[n].loc.y += speed;
                }else {
                nCars[n].loc.y += 0;
                } //Stand still 
            }else {
                nCars[n].loc.y += 0;
            } //Stand still
            nCars[n].drawCar(brush);
        }
        
        //*SouthCars
        for (int s = 0; s < SBCars; s++) {
            boolean noCollision = true;
            boolean clearLane = true;
            for(int c = 0; c<s ;c++)
            {
                if(clearLane && (sCars[c].loc.x == sCars[s].loc.x))
                {clearLane = false;}
                else if(clearLane && (sCars[c].loc.x != sCars[s].loc.x))
                {clearLane = true;}
            
                if ((sCars[c].loc.x == sCars[s].loc.x) && ((sCars[c].loc.y+SmartCar.carLength)+bump < sCars[s].loc.y ))
                {noCollision = true;}
                else if ((sCars[c].loc.x == sCars[s].loc.x) && (sCars[c].loc.y+SmartCar.carLength)+bump >= (sCars[s].loc.y))
                {noCollision = false;}
            }
            
            if ((s==0)||(s>0 && (noCollision || clearLane)))
            {   
                if (intersection.getSouthMove()||(sCars[s].loc.y > Intersection.intersectionSE + slowDown) || (sCars[s].loc.y < Intersection.intersectionSE)) {
                    sCars[s].loc.y -= vel;
                } else if (!intersection.getSouthMove() && (sCars[s].loc.y <= Intersection.intersectionSE + slowDown && sCars[s].loc.y > Intersection.intersectionSE)) {
                    sCars[s].loc.y -= speed;
                } else {
                   sCars[s].loc.y -= 0;
            } //Stand still
            }else {
                   sCars[s].loc.y -= 0;
            } //Stand still
            sCars[s].drawCar(brush);
        }
        //*EastCars
        for (int e = 0; e < EBCars; e++) {
            boolean noCollision = true;
            boolean clearLane = true;
            for(int c = 0; c<e ;c++)
            {
                if(clearLane && (eCars[c].loc.y == eCars[e].loc.y))
                {clearLane = false;}
                else if(clearLane && (eCars[c].loc.y != eCars[e].loc.y))
                {clearLane = true;}
            
                if ((eCars[c].loc.y == eCars[e].loc.y) && ((eCars[c].loc.x+SmartCar.carLength)+bump < eCars[e].loc.x ))
                {noCollision = true;}
                else if ((eCars[c].loc.y == eCars[e].loc.y) && (eCars[c].loc.x+SmartCar.carLength)+bump >= (eCars[e].loc.x))
                {noCollision = false;}
            }
            
            if ((e==0)||(e>0 && (noCollision || clearLane)))
            {
                if (intersection.getEastMove()||(eCars[e].loc.x > Intersection.intersectionSE + slowDown) || (eCars[e].loc.x < Intersection.intersectionSE)) {
                    eCars[e].loc.x -= vel;
                }else if (!intersection.getEastMove() && (eCars[e].loc.x <= Intersection.intersectionSE + slowDown && eCars[e].loc.x > Intersection.intersectionSE)) {
                    eCars[e].loc.x -= speed;
                }else {
                    eCars[e].loc.x -= 0;
                } //Stand still
            }else {
                eCars[e].loc.x -= 0;
            } //Stand still
            eCars[e].drawCar(brush);
        }
            
        //*WestCars
        for (int w = 0; w < WBCars; w++) {
            boolean noCollision = true;
            boolean clearLane = true;
            for(int c = 0; c<w ;c++)
            {
                if(clearLane && (wCars[c].loc.y == wCars[w].loc.y))
                {clearLane = false;}
                else if(clearLane && (wCars[c].loc.y != nCars[w].loc.y))
                {clearLane = true;}
            
                if ((wCars[c].loc.y == wCars[w].loc.y) && (wCars[c].loc.x-bump > wCars[w].loc.x+SmartCar.carLength))
                {noCollision = true;}
                else if ((wCars[c].loc.y == wCars[w].loc.y) && (wCars[c].loc.x-bump <= wCars[w].loc.x+SmartCar.carLength))
                {noCollision = false;}
            }
            
            if ((w==0)||(w>0 && (noCollision || clearLane)))
            {
                if (intersection.getWestMove()||(wCars[w].loc.x < (Intersection.intersectionNW-SmartCar.carLength)-slowDown)||(wCars[w].loc.x > (Intersection.intersectionNW-SmartCar.carLength))) {
                    wCars[w].loc.x += vel;
                } else if (!intersection.getWestMove() && (wCars[w].loc.x >= (Intersection.intersectionNW-SmartCar.carLength)-slowDown && wCars[w].loc.x < (Intersection.intersectionNW-SmartCar.carLength))) {
                    wCars[w].loc.x += speed;
                } else {
                 wCars[w].loc.x += 0;
                } //Stand still
            }else {
                 wCars[w].loc.x += 0;
                } //Stand still
            wCars[w].drawCar(brush);
        }
    }

    synchronized void launchNorth() {
        int buff = 7;
        //*Do While there are still cars to generate 
        boolean nextCar = NBCars > 0;
        if (nextCar && (nCars[NBCars - 1].loc.y >= (SmartCar.carLength + buff))) // if precedding car far off enought get to start position
        //*Launch car only if it the lead if far off enough
        {
            north = NL;
            if (randCar() % 2 == 0) {
                north = NL;
            } else {
                north = NR;
            }
            nCars[NBCars] = new SmartCar(NBCars, north, NSP, false);
            nCars[NBCars].carImage = northCars[randCol()];//pick a random car color
            System.out.println("Good Launch");
            NBCars++;//Number of cars on the road
        }
    }//end launch

    synchronized void launchSouth() {
        int buff = 7;
        //*Do While there are still cars to generate 
        boolean nextCar = SBCars > 0;
        if (nextCar && (sCars[SBCars - 1].loc.y <= (FrameY - SmartCar.carLength - buff))) // if precedding car far off enought get to start position
        //*Launch car only if it the lead if far off enough
        {
            south = SL;
            if (randCar() % 2 == 0) {
                south = SL;
            } else {
                south = SR;
            }
            sCars[SBCars] = new SmartCar(SBCars, south, SSP, false);
            sCars[SBCars].carImage = southCars[randCol()];//pick a random car color
            System.out.println("Good Launch");
            SBCars++;
        }
    }//end launchSouth()

    synchronized void launchWest() {
        int buff = 7;
        //*Do While there are still cars to generate 
        boolean nextCar = WBCars > 0;
        if (nextCar && (wCars[WBCars - 1].loc.x >= (SmartCar.carLength + buff))) // if precedding car far off enought get to start position
        //*Launch car only if it the lead if far off enough
        {
            west = WL;
            if (randCar() % 2 == 0) {
                west = WL;
            } else {
                west = WR;
            }
            wCars[WBCars] = new SmartCar(false, WBCars, WSP, west);
            wCars[WBCars].carImage = westCars[randCol()];//pick a random car color
            System.out.println("Good Launch");
            WBCars++;
            //cars to generate - 1
        }
    }//end launchWest()

    synchronized void launchEast() {
        int buff = 7;
        //*Do While there are still cars to generate 
        boolean nextCar = EBCars > 0;
        if (nextCar && (eCars[EBCars - 1].loc.x <= (FrameX - SmartCar.carLength - buff))) // if precedding car far off enought get to start position
        //*Launch car only if it the lead if far off enough
        {
            east = EL;
            if (randCar() % 2 == 0) {
                east = EL;
            } else {
                east = ER;
            }
            eCars[EBCars] = new SmartCar(false, EBCars, ESP, east);
            eCars[EBCars].carImage = eastCars[randCol()];//pick a random car color
            System.out.println("Good Launch East");
            EBCars++;
            //cars to generate - 1
        }
    }//end launchEast()

    public void generate() //*Generate a new set of cars when the simulation ends
    {
        System.out.println("generate");
        nNCars = 4/*randCar()*/;
        nSCars = randCar();
        nECars = randCar();
        nWCars = randCar(); //where is number of; S=south, etc ...

        //*Lane Positions
        int laneSpc = 7;
        NL = intersection.roadNSCen - (intersection.laneSize + SmartCar.carWidth + laneSpc);
        SL = intersection.roadNSCen + laneSpc;
        EL = intersection.roadEWCen - (intersection.laneSize) - SmartCar.carWidth - laneSpc;
        WL = intersection.roadEWCen + laneSpc/*308*/;

        SR = intersection.roadNSCen + (intersection.laneSize + laneSpc);
        NR = intersection.roadNSCen - laneSpc - SmartCar.carWidth;
        WR = intersection.roadEWCen + (intersection.laneSize + laneSpc);
        ER = intersection.roadEWCen - laneSpc - SmartCar.carWidth;

        //*Start Positions
        NSP = -SmartCar.carLength + 7;
        SSP = FrameY - 7;
        ESP = FrameX - 7;
        WSP = -SmartCar.carLength + 7;

        //*Let the road know how many cars it has
        nCars = new SmartCar[nNCars];
        sCars = new SmartCar[nSCars];
        eCars = new SmartCar[nECars];
        wCars = new SmartCar[nWCars];
    }//end generate()

    public int randCar() //random number of cars to place on a lane
    {//maximum of 3 cars per lane
        int temp;
        temp = (int) (Math.random() * 3) + 1;
        return temp;
    }//end randCar()

    public int randCol() //random type of car to choose
    {
        int temp;
        temp = (int) (Math.random() * 5) + 0;
        return temp;
    }//end randCol

    @Override
    public void update(Graphics g)throws NullPointerException {
        paint(g);
    }

    public Graphics2D rendering(Graphics2D brush) {
        brush.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        brush.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        brush.setRenderingHint(RenderingHints.KEY_DITHERING, RenderingHints.VALUE_DITHER_ENABLE);
        brush.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
        brush.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
        brush.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);
        brush.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        return brush;
    }//end rendering

    synchronized void carImage() {

        northCarNames = new String[]{"Cars/rich1C270.png", "Cars/rich1P270.png", "Cars/rich1S527.png",
            "Cars/rich2G270.png", "Cars/rich2R270.png", "Cars/rich2W270.png"};

        southCarNames = new String[]{"Cars/rich1C90.png", "Cars/rich1P90.png", "Cars/rich1S590.png",
            "Cars/rich2G90.png", "Cars/rich2R90.png", "Cars/rich2W90.png"};

        eastCarNames = new String[]{"Cars/rich1C180.png", "Cars/rich1P180.png", "Cars/rich1S518.png",
            "Cars/rich2G180.png", "Cars/rich2R180.png", "Cars/rich2W180.png"};

        westCarNames = new String[]{"Cars/rich1C0.png", "Cars/rich1P0.png", "Cars/rich1S500.png",
            "Cars/rich2G0.png", "Cars/rich2R0.png", "Cars/rich2W0.png"};

        int images = 6;
        northCars = new Image[images];
        southCars = new Image[images];
        eastCars = new Image[images];
        westCars = new Image[images];

        //fill image arrays with the car names
        int mt = 1;
        for (int i = 0; i < images; i++, mt++) {
            northCars[i] = getImage(getCodeBase(), northCarNames[i]);
            media.addImage(northCars[i], mt);
        }
        for (int i = 0; i < images; i++, mt++) {
            southCars[i] = getImage(getCodeBase(), southCarNames[i]);
            media.addImage(southCars[i], mt);
        }
        for (int i = 0; i < images; i++, mt++) {
            eastCars[i] = getImage(getCodeBase(), eastCarNames[i]);
            media.addImage(eastCars[i], mt);
        }
        for (int i = 0; i < images; i++, mt++) {
            westCars[i] = getImage(getCodeBase(), westCarNames[i]);
            media.addImage(westCars[i], mt);
        }
    }//end carImage()    
}//end Class
